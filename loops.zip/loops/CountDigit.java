import java.util.Scanner;

public class CountDigit {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the Number");
        int count = 0;
        // for(int n = scanner.nextInt();n!=0;n=n/10){
        //     count++;
        // }
            int n = scanner.nextInt();
            while(n!=0){
                n = n/10;
                count++;
            }

        System.out.println(count);
        scanner.close();
    }
}
