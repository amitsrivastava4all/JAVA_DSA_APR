class Fibo{
    public static void main(String[] args) {
        int first = 0;
        int second = 1;
        int nthTerm= 10;
        // Loop 1 to nth Term
        for(int i= 1; i<=nthTerm; i++){
            System.out.println(first);
            int third = first + second;


            //System.out.println(third);
            first = second;
            second = third;
        }

    }
}