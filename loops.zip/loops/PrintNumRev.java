public class PrintNumRev {
    public static void main(String[] args) {
        // Print Digits
        // 1. Count Digits
        int n = 12345;
        int e = n; // Makes a Copy
        int count = 0;
        while(n!=0){
            n = n/10;
            count++;
        }
        // 2. Make Power
        int i = 1;
        int pow = 1;
        // while(i<=count-1){
        //     pow = pow * 10;
        //     i++;
        // }
        pow = (int)Math.pow(10, count-1);
        //pow = pow/10;
        while(e!=0){
            System.out.println(e/pow);
            e = e%pow;
            pow = pow/10;

        }


       /* int n = 12345;
        while(n!=0){
            System.out.println(n%10);
            n = n/10; // make it small
        }*/

    }
}
