public class Table {
 public static void main(String[] args) {
     // num = 5
     // 5 * 1 = 5
     // 5 * 2 = 10
     // 5 * 3 =
     // 5 * 10
     // start =1 end = 10 one increment
     int num = 5;
     for(int i = 1; i<=10; i++){
         System.out.println(num+ " * "+i+" = "+(num*i));
     }
 }
}
