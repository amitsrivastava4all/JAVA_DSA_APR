public class Prime {
    public static void main(String[] args) {
        int num = 120;
        int divideCount= 0;
        for(int i = 2; i<=Math.sqrt(num); i++){
            if(num%i==0){
                divideCount++;
            }
        }
        System.out.println(divideCount==0?"Prime No":"Not a Prime No");
        /*
        for(int i = 2; i<=num; i++){
            if(num%i==0){
                    divideCount++;
            }
            if(divideCount>1){
                System.out.println("Not a Prime Number");
                //break; // exit from the loop
                return ; // exit from the function
            }
        } // for loop ends
        System.out.println("Prime Number");
        */
        // if(divideCount>1){
        //     System.out.println("Not a Prime Number");
        // }
        // else{
        //     System.out.println("Prime Number");
        // }
    }
}
